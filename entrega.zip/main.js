const alumnos = [];
const cursos = [];

class Alumno {
  constructor(nombre, apellido, curso) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.curso = curso;
  }
}

class Curso {
  constructor(nombre, fechaInicio) {
    this.nombre = nombre;
    this.fechaInicio = fechaInicio;
    this.cantidadAlumnos = 0;
  }
}

cursos.push(new Curso("Guitarra", "10/08"));
cursos.push(new Curso("Piano", "18/08"));
cursos.push(new Curso("Canto", "11/09"));
cursos.push(new Curso("Bateria", "19/09"));
cursos.push(new Curso("Vientos", "23/09"));


function encontrarCurso(arrayCursos, cursoAEncontrar) {
  for (curso of arrayCursos) {
    if (cursoAEncontrar == curso.nombre) return curso;
  }
}

function encontrarIndice(arrayCursos, cursoAEncontrar) {
  for (curso of arrayCursos) {
    if (cursoAEncontrar == curso.nombre) return arrayCursos.indexOf(curso);
  }
}



function ingresarAlumnos() {
  let nombre;
  do {
    nombre = prompt("Ingrese el nombre del alumno a inscribirse");
    if (nombre == "") {
      break;
    }

    let apellido = prompt("Ingrese el apellido del alumno a inscribirse");
    let curso = prompt("Ingrese el nombre del curso a inscribirse");
    let alumno = new Alumno(nombre, apellido, curso);
    let cursoEncontrado = encontrarCurso(cursos, curso); //find

    if (cursoEncontrado) {
      if (cursoEncontrado.cantidadAlumnos < 3) {
        alumnos.push(alumno);
        let indice = encontrarIndice(cursos, curso); //findIndex
        cursos[indice].cantidadAlumnos += 1;
        alert(
          "La fecha de inicio es " +
            cursos[indice].fechaInicio +
            " y la cantidad de inscriptos es " +
            cursos[indice].cantidadAlumnos
        );
      } else {
        alert("Los cupos estan llenos");
      }
    } else {
      alert("El curso no existe");
    }
  } while (nombre != "");
}

ingresarAlumnos();
